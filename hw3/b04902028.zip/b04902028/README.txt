For Q7 (corresponding to Q15 in coursera), type python(2) Q15.py to run the program.
The program will produce the histogram automatically.
For Q8 and Q9 (corresponding to Q19 and Q20 in coursera), change input file (for train.txt and test.txt) to correct filename.
Type python(2) Q1920.py to run the program.
The program will produce the curve figures for lr = 0.01 and lr = 0.001 for Ein and Eout with GD and SGD.
