For Q7, corresponding code is Q14.py. 
The program will produce figure automatically. 
The only thing have to do is to change the training data name to "train.txt" and testing data to "test.txt"
For Q8, corresponding code is Q16.py.
The other same as mentioned above, change file names and the program will produce result and figure.
Python version is python 2.7